package RawData;

import java.util.List;

public class Car {
    private String model;
    private int enginePower;
    private String cargoType;
    private List<Double> tyrePressure;

    public Car(String model, int enginePower, String cargoType, List<Double> tyrePressure) {
        this.model = model;
        this.enginePower = enginePower;
        this.cargoType = cargoType;
        this.tyrePressure = tyrePressure;
    }

    public String getCargoType() {
        return this.cargoType;
    }

    public int getEnginePower() {
        return enginePower;
    }

    public List<Double> getTyrePressure() {
        return tyrePressure;
    }

    public String toString() {
        return String.format("%s", this.model);
    }
}