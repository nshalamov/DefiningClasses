package RawData;

import org.w3c.dom.ls.LSOutput;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        Set<Car> cars = new LinkedHashSet<>();

        while(n-- > 0) {
            String[] tokens = scan.nextLine().split("\\s+");
            String model = tokens[0];
            int enginePower = Integer.parseInt(tokens[2]);
            String cargoType = tokens[4];
            double tyre1 = Double.parseDouble(tokens[5]);
            double tyre2 = Double.parseDouble(tokens[7]);
            double tyre3 = Double.parseDouble(tokens[9]);
            double tyre4 = Double.parseDouble(tokens[11]);
            List<Double> tyrePressure = List.of(tyre1, tyre2,tyre3,tyre4);

            Car car = new Car(model, enginePower, cargoType, tyrePressure);
            cars.add(car);
        }

        String cargoType = scan.nextLine();
        if (cargoType.equals("fragile")) {
            cars
                    .stream()
                    .filter(c -> c.getCargoType().equals(cargoType))
                    .filter(c -> {
                        List<Double> current = c.getTyrePressure();
                        for (Double t : current) {
                            if (t < 1.0) {
                                return true;
                            }
                        }
                        return false;
                    })
                    .forEach(c -> System.out.println(c.toString()));
        } else {
            cars
                    .stream()
                    .filter(c -> c.getCargoType().equals(cargoType))
                    .filter(c -> {
                        int current = c.getEnginePower();
                        return current > 250;
                    })
                    .forEach(c -> System.out.println(c.toString()));
        }
    }
}
