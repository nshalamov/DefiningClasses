package Google;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String input = scan.nextLine();

        Map<String, Person> people = new HashMap<>();

        while (!input.equals("End")) {
            String[] tokens = input.split("\\s+");
            String personName = tokens[0];
            String indicator = tokens[1];
            Person person = new Person();
            switch (indicator) {
                case "company":
                    String companyName = tokens[2];
                    String department = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);
                    Company company = new Company(companyName, department, salary);
                    person.setCompany(company);
                    if (contains(people, personName)) {
                        people.put(personName, person);
                    } else {
                        people.get(personName).setCompany(company);
                    }

                    break;
                case "pokemon":
                    String pokemonName = tokens[2];
                    String pokemonType = tokens[3];
                    Pokemon pokemon = new Pokemon(pokemonName, pokemonType);
                    if (contains(people, personName)) {
                        person.getPokemon().add(pokemon);
                        people.put(personName, person);
                    } else {
                        people.get(personName).getPokemon().add(pokemon);
                    }

                    break;
                case "parents":
                    String parentName = tokens[2];
                    String parentBirthday = tokens[3];
                    Parent parent = new Parent(parentName, parentBirthday);
                    if (contains(people, personName)) {
                        person.getParents().add(parent);
                        people.put(personName, person);
                    }else {
                        people.get(personName).getParents().add(parent);
                    }

                    break;
                case "children":
                    String childName = tokens[2];
                    String childBirthday = tokens[3];
                    Child child = new Child(childName, childBirthday);
                    if (contains(people, personName)) {
                        person.getChildren().add(child);
                        people.put(personName, person);
                    }else {
                        people.get(personName).getChildren().add(child);
                    }

                    break;
                case "car":
                    String carModel = tokens[2];
                    int carSpeed = Integer.parseInt(tokens[3]);
                    Car car = new Car(carModel, carSpeed);
                    person.setCar(car);
                    if (contains(people, personName)) {
                        people.put(personName, person);
                    } else {
                        people.get(personName).setCar(car);
                    }

                    break;
            }

            input = scan.nextLine();
        }

        input = scan.nextLine();

        String finalInput = input;
        people
                .entrySet()
                .stream()
                .filter(p -> p.getKey().equals(finalInput))
                .forEach(person -> {
                    System.out.println(person.getKey());
                    if (people.get(finalInput).getCompany() == null) {
                        System.out.println("Company:");
                    } else {
                        System.out.println(person.getValue().getCompany());
                    }
                    if (people.get(finalInput).getCar() == null) {
                        System.out.println("Car:");
                    } else {
                        System.out.println(person.getValue().getCar());
                    }
                    System.out.println("Pokemon:");
                    if (people.get(finalInput).getPokemon() != null) {
                        List<Pokemon> pokemon = people.get(finalInput).getPokemon();
                        for (Pokemon p : pokemon) {
                            System.out.println(p + " ");
                        }
                    }


                    System.out.println("Parents:");
                    List<Parent> parent = people.get(finalInput).getParents();
                    for (Parent pa : parent) {
                        System.out.println(pa + " ");
                    }

                    System.out.println("Children:");
                    List<Child> children = people.get(finalInput).getChildren();
                    for (Child c : children) {
                        System.out.println(c +" ");
                    }
                });
    }

    private static boolean contains(Map<String, Person> people, String personName) {
        return !people.containsKey(personName);
    }
}
