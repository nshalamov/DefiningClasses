package Google;

public class Pokemon {
    private String pokemonName;
    private String getPokemonType;

    public Pokemon(String pokemonName, String pokemonType) {
        this.pokemonName = pokemonName;
        this.getPokemonType = pokemonType;
    }

    public String getPokemonName() {
        return pokemonName;
    }

    public void setPokemonName(String pokemonName) {
        this.pokemonName = pokemonName;
    }

    public String getGetPokemonType() {
        return getPokemonType;
    }

    public void setGetPokemonType(String getPokemonType) {
        this.getPokemonType = getPokemonType;
    }

    @Override
    public String toString() {
        return String.format("%s %s", this.pokemonName, this.getPokemonType);
    }
}
