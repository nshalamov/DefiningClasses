package CarSalesman;

public class Car {
    private String model;
    private Engine engine;
    private int weight;
    private String colour;

    public Car(String model, Engine engine) {
        this.model = model;
        this.engine = engine;
        this.weight = -1;
        this.colour = "n/a";
    }

    public Car(String model, Engine engine, int weight) {
        this(model, engine);
        this.weight = weight;
    }

    public Car(String model, Engine engine, String colour) {
        this(model, engine);
        this.colour = colour;
    }

    public Car(String model, Engine engine, int weight, String colour) {
        this(model, engine, weight);
        this.colour = colour;
    }

    @Override
    public String toString() {
        return this.model + ":" + System.lineSeparator() +
                this.engine.toString() +
                "Weight: " +
                (this.weight == -1 ? "n/a" : this.weight) + System.lineSeparator() +
                "Color: " + this.colour;
    }
}