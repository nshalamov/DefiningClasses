package CarSalesman;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        Map<String, Engine> engines = new HashMap<>();
        // Engine input
        while (n-- > 0) {
            Engine engine;
            String[] tokens = scan.nextLine().split("\\s+");
            if (tokens.length == 4) {
                engine = new Engine(tokens[0], Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]), tokens[3]);
            } else if (tokens.length == 3) {
                try {
                    int displacement = Integer.parseInt(tokens[2]);
                    engine = new Engine(tokens[0], Integer.parseInt(tokens[1]), displacement);
                } catch (NumberFormatException ex) {
                    String colour = tokens[2];
                    engine = new Engine(tokens[0], Integer.parseInt(tokens[1]), colour);
                }
            } else {
                engine = new Engine(tokens[0], Integer.parseInt(tokens[1]));
            }

            engines.put(tokens[0], engine);
        }

        int m = Integer.parseInt(scan.nextLine());
        List<Car> cars = new ArrayList<>();
        while (m-- > 0) {
            Car car;
            String[] tokens = scan.nextLine().split("\\s+");
            if (tokens.length == 4) {
                car = new Car(tokens[0], engines.get(tokens[1]), Integer.parseInt(tokens[2]), tokens[3]);
            } else if (tokens.length == 3) {
                try {
                    int weight = Integer.parseInt(tokens[2]);
                    car = new Car(tokens[0], engines.get(tokens[1]), weight);
                } catch (NumberFormatException ex) {
                    String colour = tokens[2];
                    car = new Car(tokens[0], engines.get(tokens[1]), colour);
                }
            } else {
                car = new Car(tokens[0], engines.get(tokens[1]));
            }

            cars.add(car);
        }

        for (Car car : cars) {
            System.out.println(car.toString());
        }
    }
}