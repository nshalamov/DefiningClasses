package PokemonTrainer;

public class Pokemon {
    private String name;
    private String element;
    private int hp;

    public Pokemon(String name, String element, int hp) {
        this.name = name;
        this.element = element;
        this.hp = hp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getElement() {
        return element;
    }

    public void setElement(String element) {
        this.element = element;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }
}
