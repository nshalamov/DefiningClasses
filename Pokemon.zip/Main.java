package PokemonTrainer;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();
        Map<String, Trainer> trainers = new LinkedHashMap<>();
        while (!input.equals("Tournament")) {
            String[] tokens = input.split("\\s+");
            String trainerName = tokens[0];
            String pokemonName = tokens[1];
            String pokemonElement = tokens[2];
            int pokemonHp = Integer.parseInt(tokens[3]);

            Pokemon pokemon = new Pokemon(pokemonName, pokemonElement, pokemonHp);
            Trainer trainer = new Trainer(trainerName);
            trainer.getPokemons().add(pokemon);

            if (!trainers.containsKey(trainerName)) {
                trainers.put(trainerName, trainer);
            } else {
                trainers.get(trainerName).getPokemons().add(pokemon);
            }

            input = scan.nextLine();
        }

        String element = scan.nextLine();

        while (!element.equals("End")) {
            boolean notFound = true;
            for (Map.Entry<String, Trainer> entry : trainers.entrySet()) {
                List<Pokemon> current = entry.getValue().getPokemons();
                for (Pokemon pokemon : current) {
                    if (pokemon.getElement().contains(element)) {
                        notFound = false;
                    }
                }

                if (!notFound) {
                    int currentBadges = entry.getValue().getBadges();
                    entry.getValue().setBadges(currentBadges + 1);
                } else {
                    for (Pokemon pokemon : current) {
                        int currentHp = pokemon.getHp();
                        pokemon.setHp(currentHp - 10);
                    }

                    current.removeIf(pokemon1 -> pokemon1.getHp() <= 0);
                }
                notFound = true;
            }

            element = scan.nextLine();
        }

        trainers.entrySet()
                .stream()
                .sorted((t1, t2) -> t2.getValue().getBadges() - t1.getValue().getBadges())
                .forEach(t -> System.out.println(t.getKey() + " " + t.getValue().getBadges() + " " +
                        t.getValue().getPokemons().size()));
    }
}